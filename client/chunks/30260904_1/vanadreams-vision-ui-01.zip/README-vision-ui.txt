Vanadreams Vision interface

Vision's interface changes, applied to the current Square Enix interface file (ROM/119/51.DAT):
the cursor and wait arrows, the button bars, the main font, the gauge sheet and the PlayOnline logo dots.

Interface tweaks by Drauku and Caradog (XI-Vision, github.com/Drauku/FFXI-Vision).
Loaded through XIPivot, so your own game files stay as they are.
